
# Models are included inside app.py for simplicity in this demo.
# If you prefer a separate models.py, extract classes from app.py and import db from app.
